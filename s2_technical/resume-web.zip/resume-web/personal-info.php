<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel = "stylesheet" href= "resume.css">
</head>
<body>

<h1 class = "personal-info">Personal Information</h1>
<div class = "header">
        <div class = "column">
    <?php
    
    echo "</br>";
    echo "</br>";
    echo "</br>";
         $name = "Chorong Kim</br>";
         $school = "FEU Institute of Technology</br>";
         $address = "The One P. Campa</br>";
         $number = "9300846324</br>";
         $email = "kimchorong104@fit.edu.ph</br>";

         echo "$name";
         echo "$school";
         echo "$address";
         echo "$number";
         echo "$email";

         echo "</br>";
         echo "</br>";
    ?>
    </div>
    <div class = "column">
    <img src="img.png" alt="Profile Picture"> 
 </div>    
</body>
</html>
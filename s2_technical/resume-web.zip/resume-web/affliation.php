<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="resume.css">
    <title>Document</title>
</head>
<body>

<h2>Affliation</h2>

<?php
echo "Affliated with FEU TECH as a 2nd year Bachelor of Computer Science, Software Engineering student.</br>";
echo "Junior Officer of FEU TECH Association of Computing Machinery.";
?>
    
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href= "resume.css">
    <title>Document</title>
</head>
<body>
<h2>Technical</h2>
        <?php
            $technical = "- C++, Java, Javascript, HTML, CSS, SQL, Assembly";
            echo $technical;
            echo "</br>";
        ?>
    


        <h2>Languages</h2>
        <?php
            $language = "Fluent in Written and Spoken English</br>Fluent in Written and Spoken Tagalog</br>
            Basic Conversational Proficiency in Korean</br>";
            echo $language;
        ?>
</body>
</html>
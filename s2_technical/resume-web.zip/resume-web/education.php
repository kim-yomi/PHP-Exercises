<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href= "resume.css">
    <title>Document</title>
</head>
<body>
<h2>Education</h2>
        <?php
            $education1 = "FEU Institute of Technology | 2023 - Present</br>Bachelor of Computer Science,
            Software </br>Engineering</br>Maryhill Coll;ege | 2012 - 2023</br>With Honors, Academic Excellence Award";
            echo $education1;
        ?>
    
</body>
</html>
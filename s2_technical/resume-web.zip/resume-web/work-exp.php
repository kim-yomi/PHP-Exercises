<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="resume.css">
    <title>Document</title>
</head>
<body>

<h2>Work Experience</h2>
<?php
            $exp = "Association of Computing Machinery in FEU Institute of Technology</br>Junior Officer in Publications</br>
            2024 - 2025</br>- Authored relevant articles and event captions for the organization</br>
            Participated in leadership training and attended seminars related to course work</br></br>KKFI x FEU TECH Partnership for Tondo Microsavings Group</br>Lead Volunteer in
        KKFI x FEU TECH Partnership with Tondo Microsavings Group</br>2023 - 2024</br>Partnered with
        Kapatiran, Kaunlaran Foundation Inc., to conduct coursework in Happyland, Tondo</br>
        Lead speaker in conducting a seminar in reading literacy targeted to the children of members of Tondo</br>
        Microsavings Group in Happyland, Tondo Metro Manila";
            echo $exp;
        ?>
    
</body>
</html>
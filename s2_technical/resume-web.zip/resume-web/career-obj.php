<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href= "resume.css">
    <title>Document</title>
</head>
<body>
    <div class ="career-objective">
<?php
          
            echo "I’m a skilled speaker and presenter, and have experience in leading presentations
    and seminars. I approach setbacks with patience, choosing to focus on the bigger
    picture instead of prioritizing what is only in front of me. I can assure that I’m a
    hard worker, and will be able to handle any situation confidently.</br>
    
    My career objectives is to first and foremost, to learn. I want to able to be constantly evolving and advancing
    my skills, and to be able to apply them in a real-world setting. I want to be able to
    work with a team of like-minded individuals, and to be able to contribute to the success of the organization.";
 
?>
    </div>
</body>
</html>
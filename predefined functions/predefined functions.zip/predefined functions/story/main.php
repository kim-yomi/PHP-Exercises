<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel = "stylesheet" href ="pages/pages.css">
</head>
<body>
    <?php
    require "pages/fracture.php";
    require "pages/taste.php";
    require "pages/tvs.php";
    require "pages/orpheum.php";
    require "pages/fairest.php";
    ?>
    <div class = "sub-header">
    <a href = "/CCS0043-TN26/PHP%20Exercises/predefined%20functions/story/story.php">Back</a>
</div>
</body>
</html>


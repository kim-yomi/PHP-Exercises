<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href="pages.css">

    <title>Document</title>
</head>
<body>
    <div class = "header">
        <a href = "https://www.goodreads.com/book/show/18634726-the-vanishing-season">
            THE VANISHING SEASON</a>
   
    <div class = "sub-header">By Jodi Lynn Anderson</div>
    <div class = "image">
    <img src="/CCS0043-TN26/PHP%20Exercises/predefined%20functions/story/covers/thevanishingseason.png">
    </div>

    <p>What starts as an uneventful year suddenly changes. Someone is killing teenage girls, 
        and the town reels from the tragedy. As Maggie's and Pauline's worlds collide and 
        change around them, they will both experience love and loss. And by the end of the 
        book, only one of them will survive.</p>
        </div>
  
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href="pages.css">
    <title>D</title>
</head>
<body>
    <div class = "header">
        <a href = "https://www.goodreads.com/book/show/22489107-fairest">FAIREST</a>
<div class = "sub-header">By Marissa Meyer</div>
<img src="/CCS0043-TN26/PHP%20Exercises/predefined%20functions/story/covers/fairest.png">
    <p>a novella in the Lunar Chronicles series, tells the story of Princess Levana 
        before she became the tyrannical queen known for her beauty and ruthlessness.
         The novella explores Levana's life on Luna, her motivations, and the events 
         that shaped her into the villain she is portrayed as in the main series. </p>
         </div>

        </body>
</html>
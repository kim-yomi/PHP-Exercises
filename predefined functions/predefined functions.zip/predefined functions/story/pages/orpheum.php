<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href="pages.css">
    <title>Document</title>
</head>
<body>
    <div class ="header">
        <a href="https://www.goodreads.com/book/show/28933298-orpheum">ORPHEUM</a>

<div class = "sub-header">By DS Murphy</div>
<img src="/CCS0043-TN26/PHP%20Exercises/predefined%20functions/story/covers/orpheum.png">
<p>is a young adult dark fantasy romance based on Eastern European history, 
    the myths and literature of Orpheus and Pythagoras' theory of the music
     of the spheres. Readers who loved This Savage Song and Strange the Dreamer 
     will love this hypnotic mythological thriller.</p>
     </div>

</body>
</html>
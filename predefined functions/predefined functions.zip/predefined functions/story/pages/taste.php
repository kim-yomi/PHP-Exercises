<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href="pages.css">
    <title>Document</title>
</head>
<body>
    <div class = "header">
        <a href="https://www.goodreads.com/book/show/34831760-taste">TASTE</a>
<div class = "sub-header">By D.S. Murphy</div>
<div class = "image">
<img src="/CCS0043-TN26/PHP%20Exercises/predefined%20functions/story/covers/taste.png">
</div>
<p>is a dystopian vampire romance where a young woman is chosen to become a blood 
    companion for the Prince, thrust into a world of intrigue and deception. 
    She uncovers a secret about her identity that could lead to the downfall of the
     vampire elite, while also grappling with her growing feelings for the Prince. </p>
     </div>
</body>
</html>